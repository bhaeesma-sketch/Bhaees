'use client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useAuth } from '@/context/auth-context';

export function WelcomeBanner() {
    const { user } = useAuth();
    return (
        <Card className="text-center bg-transparent border-0 shadow-none animate-fade-in-pulse">
            <CardHeader className="p-4 md:p-6">
                <h1 className="text-6xl md:text-8xl font-headline font-bold glitch" data-text="CASINO CLASH">CASINO CLASH</h1>
                <CardDescription className="text-lg md:text-xl max-w-2xl mx-auto">
                    The ultimate crypto gaming experience. Provably fair, instant payouts, and a <span className="font-bold text-gold glow-gold">20% Welcome Bonus</span> on your first win.
                </CardDescription>
            </CardHeader>
             <CardContent className="flex justify-center items-center gap-4">
                <Button asChild size="lg" className="font-bold">
                    <Link href="/signup">Get 20% Bonus &rarr;</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="font-bold">
                    <Link href="/games/dice">Explore Games</Link>
                </Button>
            </CardContent>
        </Card>
    );
}
