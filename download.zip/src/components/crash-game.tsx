'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/auth-context';
import { useToast } from '@/hooks/use-toast';
import { BnbIcon, UsdtIcon } from './icons';
import { cn } from '@/lib/utils';
import { Slider } from './ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { playCrashLogic } from '@/lib/game-logic';
import type { Game } from '@/lib/types';
import { ClientSeedChanger } from './client-seed-changer';

type GameState = 'waiting' | 'running' | 'crashed';

export function CrashGame() {
  const { user, updateBalance, clientSeed, setClientSeed } = useAuth();
  const { toast } = useToast();

  const [betAmount, setBetAmount] = useState(10);
  const [autoCashout, setAutoCashout] = useState(2);
  const [gameState, setGameState] = useState<GameState>('waiting');
  const [multiplier, setMultiplier] = useState(1.0);
  const [hasCashedOut, setHasCashedOut] = useState(false);
  const [lastGameData, setLastGameData] = useState<Game | null>(null);

  const crashPointRef = useRef<number>(1.0);
  const gameIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);


  const startGame = async () => {
     if (!user || !clientSeed) {
      toast({ variant: 'destructive', title: 'Please log in to play.' });
      return;
    }
    if (betAmount <= 0 || betAmount > user.balance) {
      toast({ variant: 'destructive', title: 'Invalid bet amount.' });
      return;
    }
    if (autoCashout < 1.01) {
       toast({ variant: 'destructive', title: 'Auto cashout must be 1.01x or higher.' });
       return;
    }

    setGameState('running');
    setMultiplier(1.0);
    setHasCashedOut(false);
    setLastGameData(null);
    
    try {
      const { gameResult, finalBalance } = await playCrashLogic({ 
        userId: user.uid, 
        betAmount, 
        cashout: autoCashout, // This is for auto-cashout, manual will override
        clientSeed,
        isAutoCashout: true, // We're starting with auto-cashout in mind
      });
      
      crashPointRef.current = gameResult.roll;
      setLastGameData(gameResult);
      
      // The balance is now handled server-side, but let's sync the UI
      updateBalance(finalBalance);

      if (gameResult.win) {
         toast({
          title: `Auto-Cashed Out!`,
          description: `You won $${gameResult.profit.toFixed(2)} at ${autoCashout.toFixed(2)}x`,
          className: 'border-green-500/50',
        });
        setHasCashedOut(true);
      }

      startTimeRef.current = Date.now();
      gameIntervalRef.current = setInterval(() => {
        setMultiplier((prev) => {
          const elapsedTime = (Date.now() - startTimeRef.current) / 1000;
          const nextMultiplier = Math.pow(1.05, elapsedTime);

          if (nextMultiplier >= crashPointRef.current) {
            clearInterval(gameIntervalRef.current!);
            setGameState('crashed');
            if (!hasCashedOut) {
              toast({
                variant: 'destructive',
                title: `Crashed at ${crashPointRef.current.toFixed(2)}x`,
                description: 'Better luck next time!',
              });
            }
            return crashPointRef.current;
          }
          return nextMultiplier;
        });
      }, 50);

    } catch (e: any) {
        console.error(e);
        toast({
          variant: 'destructive',
          title: 'An error occurred',
          description: e.message || 'Failed to start game.',
        });
        setGameState('waiting');
    }
  };
  
  const handleManualCashout = async () => {
    if (gameState !== 'running' || hasCashedOut || !user || !clientSeed) return;
    
    const cashoutMultiplier = multiplier;
    clearInterval(gameIntervalRef.current!);
    setHasCashedOut(true);
      
    try {
        const { finalBalance, gameResult } = await playCrashLogic({
            userId: user.uid,
            betAmount,
            cashout: cashoutMultiplier,
            clientSeed,
            isAutoCashout: false, // This is a manual cashout
        });

        updateBalance(finalBalance);
        setLastGameData(gameResult);

        toast({
            title: 'Cashed Out!',
            description: `You won $${gameResult.profit.toFixed(2)} at ${cashoutMultiplier.toFixed(2)}x`,
            className: 'border-green-500/50',
        });
    } catch(e: any) {
        console.error(e);
        toast({
            variant: 'destructive',
            title: 'Cashout Failed',
            description: e.message || 'Could not process cashout. Balance unchanged.',
        });
        // We don't change game state here, as the game technically continues
    }
  }

  useEffect(() => {
    return () => {
      if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
    };
  }, []);

  const handleBetAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setBetAmount(isNaN(value) ? 0 : value);
  };
  
  const isBettingPhase = gameState === 'waiting' || gameState === 'crashed';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle className="font-headline text-3xl">Place Your Bet</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="bet-amount">Bet Amount</Label>
            <div className="flex items-center gap-2">
              <BnbIcon className="h-6 w-6" />
              <Input id="bet-amount" type="number" value={betAmount} onChange={handleBetAmountChange} className="text-lg" disabled={!isBettingPhase} />
              <UsdtIcon className="h-6 w-6" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="auto-cashout">Auto Cashout ({autoCashout.toFixed(2)}x)</Label>
            <Input id="auto-cashout" type="number" value={autoCashout} onChange={e => setAutoCashout(parseFloat(e.target.value))} className="text-lg" disabled={!isBettingPhase} placeholder="2.00" />
            <Slider value={[autoCashout]} onValueChange={(v) => setAutoCashout(v[0])} max={10} min={1.01} step={0.01} disabled={!isBettingPhase} />
          </div>
          <ClientSeedChanger clientSeed={clientSeed} setClientSeed={setClientSeed} disabled={!isBettingPhase} />

          {isBettingPhase ? (
            <Button onClick={startGame} disabled={!user || gameState === 'running'} className="w-full font-headline text-2xl py-6">
              {gameState === 'crashed' ? 'Play Again' : 'Place Bet'}
            </Button>
          ) : (
            <Button onClick={handleManualCashout} disabled={hasCashedOut} className="w-full font-headline text-2xl py-6 bg-accent hover:bg-accent/80">
              {hasCashedOut ? `Cashed Out!` : `Cash Out @ ${multiplier.toFixed(2)}x`}
            </Button>
          )}

          {!user && <p className="text-center text-sm text-muted-foreground">Log in to start playing!</p>}
           {lastGameData && (
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="link" size="sm" className="w-full">View Last Game Data</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Provably Fair Data</DialogTitle>
                            <DialogDescription>
                                Use these values on the /verify page to confirm the result was fair. The server seed is revealed after the bet.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 text-xs text-left overflow-auto break-words">
                            <p><strong>Unhashed Server Seed:</strong> {lastGameData.serverSeed}</p>
                            <p><strong>Server Seed Hash:</strong> {lastGameData.serverSeedHash}</p>
                            <p><strong>Client Seed:</strong> {lastGameData.clientSeed}</p>
                            <p><strong>Nonce:</strong> {lastGameData.nonce}</p>
                            <p><strong>Calculated Crash Point:</strong> {lastGameData.roll.toFixed(2)}x</p>
                        </div>
                    </DialogContent>
                </Dialog>
            )}
        </CardContent>
      </Card>
      <Card className="lg:col-span-2 flex flex-col items-center justify-center min-h-[300px] relative overflow-hidden bg-secondary">
        <div className={cn(
          "absolute text-7xl md:text-9xl font-black font-mono transition-colors duration-300",
          gameState === 'crashed' ? 'text-destructive' : 'glow-primary text-primary'
        )}>
          {multiplier.toFixed(2)}x
        </div>
        {gameState === 'crashed' && (
           <div className="absolute bottom-4 bg-destructive text-destructive-foreground px-4 py-2 rounded-md">
             Crashed @ {crashPointRef.current.toFixed(2)}x
           </div>
        )}
         {(gameState === 'waiting' || (gameState === 'crashed' && !lastGameData)) && (
           <div className="absolute text-2xl text-muted-foreground">
             {gameState === 'crashed' ? 'Round Over' : 'Waiting for next round...'}
           </div>
        )}
      </Card>
    </div>
  );
}
