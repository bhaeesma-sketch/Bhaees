'use client';

import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useToast } from "@/hooks/use-toast";
import { Settings } from "lucide-react";

interface ClientSeedChangerProps {
    clientSeed: string;
    setClientSeed: (seed: string) => Promise<void>;
    disabled?: boolean;
}

export function ClientSeedChanger({ clientSeed, setClientSeed, disabled }: ClientSeedChangerProps) {
    const [newSeed, setNewSeed] = useState(clientSeed);
    const [isEditing, setIsEditing] = useState(false);
    const { toast } = useToast();

    const handleSave = async () => {
        if (newSeed.trim() === '') {
            toast({ variant: 'destructive', title: "Client seed cannot be empty." });
            return;
        }
        try {
            await setClientSeed(newSeed);
            toast({ title: "Client Seed Updated!" });
            setIsEditing(false);
        } catch (error) {
            toast({ variant: 'destructive', title: "Failed to update seed." });
        }
    };

    if (!isEditing) {
        return (
            <div className="flex items-center justify-center gap-2">
                <p className="text-xs text-muted-foreground">Client Seed: <span className="font-mono">{clientSeed}</span></p>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setIsEditing(true)} disabled={disabled}>
                    <Settings className="h-4 w-4" />
                </Button>
            </div>
        );
    }

    return (
        <div className='flex flex-col items-center gap-2 p-4 bg-secondary/50 rounded-lg'>
            <Label htmlFor="client-seed-edit" className="text-sm">Edit Client Seed</Label>
            <div className="flex gap-2 w-full">
                <Input 
                    id="client-seed-edit" 
                    value={newSeed} 
                    onChange={e => setNewSeed(e.target.value)} 
                    disabled={disabled}
                    className="max-w-xs text-center h-8"
                />
                <Button size="sm" onClick={handleSave} disabled={disabled} className="h-8">Save</Button>
                <Button variant="ghost" size="sm" onClick={() => { setIsEditing(false); setNewSeed(clientSeed); }} disabled={disabled} className="h-8">Cancel</Button>
            </div>
        </div>
    );
}
