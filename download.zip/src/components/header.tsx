'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/auth-context';
import { Coins, Dice5, Wallet, Gamepad2, Bomb, GitCommitHorizontal } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function Header() {
  const { user, logout, loading } = useAuth();
  const pathname = usePathname();

  const gameLinks = [
    { href: '/games/dice', label: 'Dice', icon: Dice5 },
    { href: '/games/crash', label: 'Crash', icon: Gamepad2 },
    { href: '/games/mines', label: 'Mines', icon: Bomb },
    { href: '/games/coinflip', label: 'Coin Flip', icon: GitCommitHorizontal },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <Dice5 className="h-6 w-6 text-primary" />
            <span className="hidden font-bold sm:inline-block font-headline text-lg">
              Casino Clash
            </span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className={cn(
                  'transition-colors hover:text-primary',
                   pathname.startsWith('/games') ? 'text-primary' : 'text-muted-foreground'
                )}>
                  Games
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {gameLinks.map((link) => (
                  <DropdownMenuItem key={link.href} asChild>
                    <Link href={link.href} className="flex items-center gap-2">
                      <link.icon className="h-4 w-4" />
                      {link.label}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Link
              href="/wallet"
              className={cn(
                'transition-colors hover:text-primary',
                pathname === '/wallet' ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              Wallet
            </Link>
             <Link
              href="/verify"
              className={cn(
                'transition-colors hover:text-primary',
                pathname === '/verify' ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              Verify
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          {loading ? (
            <div className="h-9 w-24 animate-pulse rounded-md bg-muted"></div>
          ) : user ? (
            <>
              <div className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-sm font-medium">
                <Coins className="h-4 w-4 text-primary" />
                <span>${user.balance.toFixed(2)}</span>
              </div>
              <Button variant="outline" size="sm" onClick={logout}>
                Logout
              </Button>
            </>
          ) : (
            <div className="space-x-2">
              <Button asChild variant="ghost" size="sm">
                <Link href="/login">Log In</Link>
              </Button>
              <Button asChild size="sm">
                <Link href="/signup">Sign Up</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
