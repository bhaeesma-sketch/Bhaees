'use client';

import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/auth-context';
import { useToast } from '@/hooks/use-toast';
import { BnbIcon, UsdtIcon } from './icons';
import { Bomb, Gem } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Slider } from './ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { playMinesLogic, cashoutMinesLogic } from '@/lib/game-logic';
import type { Game } from '@/lib/types';
import { ClientSeedChanger } from './client-seed-changer';

const GRID_SIZE = 25;

type GameState = 'betting' | 'playing' | 'busted';

type CellState = 'hidden' | 'gem' | 'mine';

export function MinesGame() {
  const { user, updateBalance, clientSeed, setClientSeed } = useAuth();
  const { toast } = useToast();
  const [betAmount, setBetAmount] = useState(10);
  const [mineCount, setMineCount] = useState(5);
  const [gameState, setGameState] = useState<GameState>('betting');
  const [grid, setGrid] = useState<CellState[]>(Array(GRID_SIZE).fill('hidden'));
  const [revealedCount, setRevealedCount] = useState(0);
  const [currentProfit, setCurrentProfit] = useState(0);
  const [lastGame, setLastGame] = useState<Game | null>(null);

  const { nextPayoutMultiplier, nextProfit } = useMemo(() => {
    if (gameState !== 'playing' || revealedCount < 0) return { nextPayoutMultiplier: 0, nextProfit: 0 };
    const safeTiles = GRID_SIZE - mineCount;
    let multiplier = 1;
    for (let i = 0; i <= revealedCount; i++) {
        multiplier *= (1 - 0.01) * (safeTiles / (safeTiles - i));
    }
    const nextPayout = betAmount * multiplier;
    return {
        nextPayoutMultiplier: multiplier,
        nextProfit: nextPayout - betAmount,
    };
  }, [revealedCount, mineCount, gameState, betAmount]);

  const handleStartGame = async () => {
    if (!user || !clientSeed) {
      toast({ variant: 'destructive', title: 'Please log in to play.' });
      return;
    }
    if (betAmount <= 0 || betAmount > user.balance) {
      toast({ variant: 'destructive', title: 'Invalid bet amount.' });
      return;
    }

    setGameState('playing');
    setGrid(Array(GRID_SIZE).fill('hidden'));
    setRevealedCount(0);
    setCurrentProfit(0);
    setLastGame(null);

    try {
        const { updatedBalance } = await playMinesLogic({
            userId: user.uid,
            betAmount
        });
        updateBalance(updatedBalance);
    } catch (e: any) {
        toast({ variant: 'destructive', title: 'Failed to start game', description: e.message });
        setGameState('betting');
    }
  };
  
  const handleCellClick = async (index: number) => {
    if (gameState !== 'playing' || grid[index] !== 'hidden' || !user || !clientSeed) return;
    
    const clickedCells = grid.map((cell, i) => (cell === 'gem' || i === index) ? i : -1).filter(i => i !== -1);

    try {
        const { gameResult, finalBalance } = await playMinesLogic({
            userId: user.uid,
            betAmount,
            mineCount,
            clientSeed,
            clickedIndices: clickedCells
        });

        const newGrid = [...grid];
        if (gameResult.win) {
            newGrid[index] = 'gem';
            setGrid(newGrid);
            setRevealedCount(clickedCells.length);
            setCurrentProfit(gameResult.profit);
        } else {
            setGameState('busted');
            // Reveal all mines from the game result
            gameResult.mineLocations!.forEach(loc => newGrid[loc] = 'mine');
            // Keep revealed gems
            clickedCells.forEach(i => {
                if (!gameResult.mineLocations!.includes(i)) newGrid[i] = 'gem';
            });
            // Ensure the one that was just clicked shows as a mine
            if(gameResult.mineLocations!.includes(index)) newGrid[index] = 'mine';

            setGrid(newGrid);
            updateBalance(finalBalance);
            setLastGame(gameResult);
            toast({ variant: 'destructive', title: 'BOOM! You hit a mine.' });
        }

    } catch (e: any) {
        toast({ variant: 'destructive', title: 'Error processing click', description: e.message });
    }
  };

  const handleCashout = async () => {
    if (gameState !== 'playing' || revealedCount === 0 || !user || !clientSeed) return;

    try {
        const clickedCells = grid.map((cell, i) => cell === 'gem' ? i : -1).filter(i => i !== -1);

        const { gameResult, finalBalance } = await cashoutMinesLogic({
            userId: user.uid,
            betAmount,
            mineCount,
            clientSeed,
            clickedIndices: clickedCells
        });

        updateBalance(finalBalance);
        setGameState('busted'); 
        setLastGame(gameResult);

        const newGrid = [...grid];
        gameResult.mineLocations!.forEach((loc: number) => {
            if(newGrid[loc] === 'hidden') newGrid[loc] = 'mine';
        });
        setGrid(newGrid);

        toast({
          title: 'Cashed Out!',
          description: `You won $${gameResult.profit.toFixed(2)}`,
          className: 'border-green-500/50',
        });
        
    } catch (e: any) {
        console.error(e);
        toast({
            variant: 'destructive',
            title: 'An error occurred during cashout',
            description: e.message || 'Failed to cash out.',
        });
    }
  };

  const handleBetAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setBetAmount(isNaN(value) ? 0 : value);
  };
  
  const isGameEnded = gameState === 'busted' || gameState === 'betting';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle className="font-headline text-3xl">Place Your Bet</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="bet-amount">Bet Amount</Label>
            <div className="flex items-center gap-2">
              <BnbIcon className="h-6 w-6" />
              <Input id="bet-amount" type="number" value={betAmount} onChange={handleBetAmountChange} disabled={!isGameEnded} className="text-lg" />
              <UsdtIcon className="h-6 w-6" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Mines ({mineCount})</Label>
            <Slider value={[mineCount]} onValueChange={(v) => setMineCount(v[0])} max={20} min={3} step={1} disabled={!isGameEnded}/>
          </div>
           <ClientSeedChanger clientSeed={clientSeed} setClientSeed={setClientSeed} disabled={!isGameEnded} />

          {gameState !== 'playing' ? (
            <Button onClick={handleStartGame} disabled={!user} className="w-full font-headline text-2xl py-6">
              {gameState === 'betting' ? 'Start Game' : 'Play Again'}
            </Button>
          ) : (
            <Button onClick={handleCashout} disabled={revealedCount === 0} className="w-full font-headline text-2xl py-6 bg-accent hover:bg-accent/80">
              Cashout ${currentProfit.toFixed(2)}
            </Button>
          )}

          {!user && <p className="text-center text-sm text-muted-foreground">Log in to start playing!</p>}
           {lastGame && gameState === 'busted' && (
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="link" size="sm" className="w-full">View Last Game Data</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Provably Fair Data</DialogTitle>
                            <DialogDescription>
                                Use these values on the /verify page to confirm the result was fair.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 text-xs text-left overflow-auto break-words">
                            <p><strong>Unhashed Server Seed:</strong> {lastGame.serverSeed}</p>
                            <p><strong>Server Seed Hash:</strong> {lastGame.serverSeedHash}</p>
                            <p><strong>Client Seed:</strong> {lastGame.clientSeed}</p>
                            <p><strong>Nonce:</strong> {lastGame.nonce}</p>
                            <p><strong>Mine Locations (0-24):</strong> {lastGame.mineLocations?.sort((a,b)=> a - b).join(', ')}</p>
                        </div>
                    </DialogContent>
                </Dialog>
            )}
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardContent className="p-4">
          <div className="grid grid-cols-5 gap-2 aspect-square">
            {grid.map((cell, index) => (
              <button
                key={index}
                onClick={() => handleCellClick(index)}
                disabled={gameState !== 'playing' || cell !== 'hidden'}
                className={cn(
                  "flex items-center justify-center rounded-md aspect-square transition-all",
                  "bg-secondary hover:bg-secondary/80",
                  cell === 'gem' && "bg-green-500/20 border-2 border-green-500",
                  cell === 'mine' && "bg-red-500/20 border-2 border-red-500 animate-pulse",
                  gameState === 'playing' && cell === 'hidden' && "cursor-pointer",
                  gameState === 'busted' && grid[index] !== 'mine' && grid[index] !== 'gem' && 'bg-secondary/30 opacity-50'
                )}
              >
                {cell === 'gem' && <Gem className="h-8 w-8 text-green-400" />}
                {cell === 'mine' && <Bomb className="h-8 w-8 text-red-400" />}
              </button>
            ))}
          </div>
          <div className="flex justify-around mt-4 text-center">
            <div>
              <p className="text-muted-foreground">Gems Found</p>
              <p className="text-2xl font-bold">{revealedCount}</p>
            </div>
             <div>
              <p className="text-muted-foreground">Next Multiplier</p>
              <p className="text-2xl font-bold text-primary">{nextPayoutMultiplier.toFixed(2)}x</p>
            </div>
             <div>
              <p className="text-muted-foreground">Profit</p>
              <p className={cn("text-2xl font-bold", currentProfit >= 0 ? "text-green-400" : "text-red-500")}>${currentProfit.toFixed(2)}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
