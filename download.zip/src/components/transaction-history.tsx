'use client';

import { useMemo } from 'react';
import { useAuth } from '@/context/auth-context';
import { useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { BnbIcon, UsdtIcon } from './icons';
import { Skeleton } from './ui/skeleton';
import type { Transaction } from '@/lib/types';
import { useFirestore } from '@/firebase/provider';

export function TransactionHistory() {
  const { user } = useAuth();
  const firestore = useFirestore();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('timestamp', 'desc'),
      limit(20)
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<Transaction>(transactionsQuery);

  const getStatusVariant = (status: string): 'default' | 'secondary' | 'destructive' => {
      switch (status) {
          case 'completed': return 'default';
          case 'pending': return 'secondary';
          case 'failed': return 'destructive';
          default: return 'secondary';
      }
  }

  const getAmountColor = (type: string) => {
      return ['win', 'deposit', 'bonus'].includes(type) ? 'text-green-400' : 'text-red-400';
  }

  return (
    <>
      {isLoading && (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
        </div>
      )}
      {!isLoading && transactions && transactions.length === 0 && (
          <p className="text-muted-foreground text-center py-8">No transactions yet.</p>
      )}
      {!isLoading && transactions && transactions.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Game</TableHead>
              <TableHead className="text-right">Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((tx) => (
              <TableRow key={tx.id}>
                <TableCell className="font-medium capitalize">{tx.type}</TableCell>
                <TableCell className={`${getAmountColor(tx.type)} flex items-center gap-2`}>
                   {['win', 'bonus'].includes(tx.type) ? '+' : ['bet'].includes(tx.type) ? '-' : ''}
                   ${tx.amount.toFixed(2)}
                   {tx.currency === 'BNB' ? <BnbIcon className="w-4 h-4" /> : <UsdtIcon className="w-4 h-4" />}
                </TableCell>
                <TableCell>
                  <Badge
                    variant={getStatusVariant(tx.status)}
                    className={tx.status === 'completed' ? 'bg-green-600/80 text-white' : ''}
                  >
                    {tx.status}
                  </Badge>
                </TableCell>
                 <TableCell className="capitalize">{tx.game || 'N/A'}</TableCell>
                <TableCell className="text-right text-muted-foreground">
                  {tx.timestamp ? new Date(tx.timestamp).toLocaleDateString() : 'N/A'}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </>
  );
}
