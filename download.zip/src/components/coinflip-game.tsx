'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/auth-context';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { BnbIcon, UsdtIcon } from './icons';
import { FallingCoins } from './falling-coins';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { playCoinFlipLogic } from '@/lib/game-logic';
import type { Game } from '@/lib/types';
import { ClientSeedChanger } from './client-seed-changer';

export function CoinFlipGame() {
  const { user, updateBalance, clientSeed, setClientSeed } = useAuth();
  const { toast } = useToast();
  const [betAmount, setBetAmount] = useState(10);
  const [choice, setChoice] = useState<'heads' | 'tails' | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<'heads' | 'tails' | null>(null);
  const [showWinAnimation, setShowWinAnimation] = useState(false);
  const [lastGameData, setLastGameData] = useState<Game | null>(null);

  const handleFlip = async () => {
    if (!user || !clientSeed) {
      toast({
        variant: 'destructive',
        title: 'Not Logged In',
        description: 'Please log in or sign up to play.',
      });
      return;
    }
    if (betAmount > user.balance) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Balance',
        description: 'You do not have enough funds to place this bet.',
      });
      return;
    }
    if (!choice) {
      toast({
        variant: 'destructive',
        title: 'No Choice Made',
        description: 'Please select Heads or Tails.',
      });
      return;
    }

    setIsFlipping(true);
    setResult(null);
    setLastGameData(null);
    
    // Animate the flip
    await new Promise((resolve) => setTimeout(resolve, 1500));

    try {
        const { gameResult, finalBalance } = await playCoinFlipLogic({
            userId: user.uid,
            betAmount,
            choice,
            clientSeed,
        });

        // Update balance with the actual result from the server
        updateBalance(finalBalance);

        const flipResult = gameResult.roll === 0 ? 'heads' : 'tails';
        setResult(flipResult);

        setLastGameData(gameResult);

        if (gameResult.win) {
          setShowWinAnimation(true);
          setTimeout(() => setShowWinAnimation(false), 4000);
          toast({
            title: 'You Won!',
            description: `The coin landed on ${flipResult}. You won $${gameResult.profit.toFixed(2)}!`,
            className: 'border-green-500/50',
          });
        } else {
          toast({
            variant: 'destructive',
            title: 'You Lost',
            description: `The coin landed on ${flipResult}.`,
          });
        }

    } catch (e: any) {
       console.error(e);
       toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: e.message || 'Failed to play the game. Your balance has not been changed.',
       });
    }

    setIsFlipping(false);
  };
  
  const handleBetAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setBetAmount(isNaN(value) ? 0 : value);
  };
  
  const setBetAmountWithMultiplier = (multiplier: number) => {
    setBetAmount(prev => Math.max(0.01, parseFloat((prev * multiplier).toFixed(2))));
  }

  return (
    <>
      {showWinAnimation && <FallingCoins />}
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="font-headline text-3xl text-center">Heads or Tails?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center items-center h-48">
            <div className={cn('coin', { 'flipping': isFlipping, 'heads': result === 'heads', 'tails': result === 'tails' })}>
              <div className="side-a"></div>
              <div className="side-b"></div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="bet-amount">Bet Amount</Label>
            <div className="flex items-center gap-2">
              <BnbIcon className="h-6 w-6" />
              <Input id="bet-amount" type="number" value={betAmount} onChange={handleBetAmountChange} className="text-lg" disabled={isFlipping} />
              <UsdtIcon className="h-6 w-6" />
            </div>
            <div className="flex gap-2 mt-2">
              <Button variant="outline" size="sm" onClick={() => setBetAmountWithMultiplier(0.5)} disabled={isFlipping}>1/2</Button>
              <Button variant="outline" size="sm" onClick={() => setBetAmountWithMultiplier(2)} disabled={isFlipping}>2x</Button>
              <Button variant="outline" size="sm" onClick={() => setBetAmount(user?.balance ?? 0)} disabled={isFlipping}>Max</Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={choice === 'heads' ? 'default' : 'outline'}
              className="py-8 text-2xl font-bold"
              onClick={() => setChoice('heads')}
              disabled={isFlipping}
            >
              HEADS
            </Button>
            <Button
              variant={choice === 'tails' ? 'default' : 'outline'}
              className="py-8 text-2xl font-bold"
              onClick={() => setChoice('tails')}
              disabled={isFlipping}
            >
              TAILS
            </Button>
          </div>

          <Button onClick={handleFlip} disabled={isFlipping || !user} className="w-full font-headline text-2xl py-6">
            {isFlipping ? 'Flipping...' : 'Flip Coin'}
          </Button>
          {!user && <p className="text-center text-sm text-muted-foreground">Log in to start playing!</p>}
          <div className="text-center text-muted-foreground text-sm space-y-2">
            <p>Payout: 1.98x (1% House Edge)</p>
            <ClientSeedChanger clientSeed={clientSeed} setClientSeed={setClientSeed} disabled={isFlipping} />
             {lastGameData && (
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="link" size="sm">View Last Game Data</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Provably Fair Data</DialogTitle>
                            <DialogDescription>
                                Use these values on the /verify page to confirm the result was fair. The server seed is revealed after the bet.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 text-xs text-left overflow-auto break-words">
                            <p><strong>Unhashed Server Seed:</strong> {lastGameData.serverSeed}</p>
                            <p><strong>Server Seed Hash:</strong> {lastGameData.serverSeedHash}</p>
                            <p><strong>Client Seed:</strong> {lastGameData.clientSeed}</p>
                            <p><strong>Nonce:</strong> {lastGameData.nonce}</p>
                            <p><strong>Your Choice:</strong> {choice}</p>
                            <p><strong>Coin Result:</strong> {lastGameData.roll === 0 ? 'Heads' : 'Tails'}</p>
                            <p><strong>Win:</strong> {lastGameData.win ? 'Yes' : 'No'}</p>
                        </div>
                    </DialogContent>
                </Dialog>
            )}
          </div>
        </CardContent>
      </Card>
      <style jsx>{`
        .coin {
          width: 150px;
          height: 150px;
          position: relative;
          transform-style: preserve-3d;
        }
        .coin.flipping {
          animation: flip 1.5s ease-out forwards;
        }
        .coin:not(.flipping) {
            transition: transform 0.8s cubic-bezier(0.25, 1, 0.5, 1);
        }
        .coin .side-a, .coin .side-b {
          position: absolute;
          width: 100%;
          height: 100%;
          backface-visibility: hidden;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
          font-weight: bold;
          background-size: cover;
          border: 4px solid #ffd700;
          box-shadow: 0 0 15px #ffd700;
        }
        .side-a {
          background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a0/2006_Quarter_Proof.png');
          color: #fff;
          transform: rotateY(0deg);
        }
        .side-b {
          background-image: url('https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/1792_half_disme_obverse.jpg/1024px-1792_half_disme_obverse.jpg');
          color: #fff;
          transform: rotateY(180deg);
        }
        @keyframes flip {
          from { transform: rotateY(0deg); }
          to { transform: rotateY(1800deg); }
        }
        .coin.heads {
          transform: rotateY(0deg);
        }
        .coin.tails {
          transform: rotateY(180deg);
        }
      `}</style>
    </>
  );
}
