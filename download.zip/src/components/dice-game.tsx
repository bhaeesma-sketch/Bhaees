'use client';

import { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useAuth } from '@/context/auth-context';
import { useToast } from '@/hooks/use-toast';
import { applyWelcomeBonus } from '@/ai/flows/welcome-bonus-assistant';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Dice5, Star, TrendingDown, Percent, Target } from 'lucide-react';
import { FallingCoins } from './falling-coins';
import { BnbIcon, UsdtIcon } from './icons';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { playDiceLogic } from '@/lib/game-logic';
import type { Game } from '@/lib/types';
import { ClientSeedChanger } from './client-seed-changer';

export function DiceGame() {
  const { user, updateBalance, setBonusUsed, clientSeed, setClientSeed } = useAuth();
  const { toast } = useToast();
  const [betAmount, setBetAmount] = useState(10);
  const [chance, setChance] = useState(50);
  const [lastRoll, setLastRoll] = useState<{ roll: number; profit: number; win: boolean } | null>(null);
  const [isRolling, setIsRolling] = useState(false);
  const [showWinAnimation, setShowWinAnimation] = useState(false);
  const [isFirstWin, setIsFirstWin] = useState(!user?.bonusUsed);
  const [lastGameData, setLastGameData] = useState<Game | null>(null);

  useEffect(() => {
    if (user) {
      setIsFirstWin(!user.bonusUsed);
    }
  }, [user]);

  const { payoutMultiplier, winProfit } = useMemo(() => {
    if (chance <= 0.01 || chance > 99) return { payoutMultiplier: 0, winProfit: -betAmount };
    const multiplier = (100 / chance) * 0.99; // 1% house edge
    const profit = betAmount * multiplier - betAmount;
    return {
      payoutMultiplier: multiplier,
      winProfit: profit,
    };
  }, [betAmount, chance]);

  const handleRoll = async () => {
    if (!user || !clientSeed) {
      toast({ variant: 'destructive', title: 'Not Logged In', description: 'Please log in or sign up to play.' });
      return;
    }
    if (betAmount > user.balance) {
      toast({ variant: 'destructive', title: 'Insufficient Balance' });
      return;
    }
     if (chance < 0.01 || chance > 99) {
      toast({ variant: 'destructive', title: 'Invalid Chance', description: 'Win chance must be between 0.01 and 99.' });
      return;
    }

    setIsRolling(true);
    setLastGameData(null);
    setLastRoll(null);

    try {
      const { gameResult, finalBalance } = await playDiceLogic({
        userId: user.uid,
        betAmount,
        chance,
        clientSeed,
      });

      // Final balance update from server-confirmed result
      updateBalance(finalBalance);

      setLastGameData(gameResult);
      setLastRoll({ roll: gameResult.roll, profit: gameResult.profit, win: gameResult.win });

      if (gameResult.win) {
        setShowWinAnimation(true);
        setTimeout(() => setShowWinAnimation(false), 4000);

        if (isFirstWin && user && !user.bonusUsed) {
          try {
            const bonusResult = await applyWelcomeBonus({
              userId: user.uid,
              winAmount: gameResult.profit + betAmount, // Original win amount
            });
            // The bonus is applied server-side via the flow, but we need to update the local state
            updateBalance(finalBalance + bonusResult.bonusAmount);
            setBonusUsed(); // Update local context state
            setIsFirstWin(false);
            toast({
              title: 'Welcome Bonus Applied!',
              description: bonusResult.message,
              className: 'border-primary bg-primary/10',
            });
          } catch (error) {
            console.error('Failed to apply welcome bonus:', error);
            toast({
              variant: 'destructive',
              title: 'Bonus Error',
              description: 'Could not apply your welcome bonus. Please contact support.',
            });
          }
        }
      }
    } catch (e: any) {
      console.error(e);
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: e.message || 'Failed to play the game. Your balance was not changed.',
      });
    }

    setIsRolling(false);
  };
  
  const handleBetAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setBetAmount(isNaN(value) ? 0 : value);
  };

  const setBetAmountWithMultiplier = (multiplier: number) => {
    setBetAmount(prev => Math.max(0.01, parseFloat((prev * multiplier).toFixed(2))));
  }

  return (
    <>
      {showWinAnimation && <FallingCoins />}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="font-headline text-3xl flex items-center gap-2">
              <Dice5 className="text-primary" /> Place Your Bet
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="bet-amount">Bet Amount</Label>
              <div className="flex items-center gap-2">
                 <BnbIcon className="h-6 w-6" />
                <Input id="bet-amount" type="number" value={betAmount} onChange={handleBetAmountChange} className="text-lg" disabled={isRolling} />
                 <UsdtIcon className="h-6 w-6" />
              </div>
              <div className="flex gap-2 mt-2">
                <Button variant="outline" size="sm" onClick={() => setBetAmountWithMultiplier(0.5)} disabled={isRolling}>1/2</Button>
                <Button variant="outline" size="sm" onClick={() => setBetAmountWithMultiplier(2)} disabled={isRolling}>2x</Button>
                <Button variant="outline" size="sm" onClick={() => setBetAmount(user?.balance ?? 0)} disabled={isRolling}>Max</Button>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <Label>Win Chance</Label>
                <span className="font-mono text-primary">{chance.toFixed(2)}%</span>
              </div>
              <Slider value={[chance]} onValueChange={(value) => setChance(value[0])} max={99} min={0.01} step={0.01} disabled={isRolling} />
            </div>
             <ClientSeedChanger clientSeed={clientSeed} setClientSeed={setClientSeed} disabled={isRolling}/>
             <Button
              onClick={handleRoll}
              disabled={isRolling || !user}
              className="w-full font-headline text-2xl py-6"
            >
              {isRolling ? 'Rolling...' : 'Roll Dice'}
            </Button>
            {!user && <p className="text-center text-sm text-muted-foreground">Log in to start playing!</p>}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
           <CardHeader>
             <CardTitle className="font-headline text-3xl">Game Info</CardTitle>
           </CardHeader>
           <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
              <div className="p-4 bg-card-foreground/5 rounded-md">
                <p className="text-sm text-muted-foreground font-headline text-lg">Payout</p>
                <p className="text-2xl font-bold font-mono text-primary">{payoutMultiplier.toFixed(2)}x</p>
              </div>
              <div className="p-4 bg-card-foreground/5 rounded-md">
                <p className="text-sm text-muted-foreground font-headline text-lg">Win Profit</p>
                <p className="text-2xl font-bold font-mono text-green-400">+${winProfit.toFixed(2)}</p>
              </div>
               <div className="p-4 bg-card-foreground/5 rounded-md">
                <p className="text-sm text-muted-foreground font-headline text-lg flex items-center justify-center gap-1"><Target size={16}/> Roll Under</p>
                <p className="text-2xl font-bold font-mono">{chance.toFixed(2)}</p>
              </div>
              <div className="p-4 bg-card-foreground/5 rounded-md">
                <p className="text-sm text-muted-foreground font-headline text-lg flex items-center justify-center gap-1"><Percent size={16}/> House Edge</p>
                <p className="text-2xl font-bold font-mono">1%</p>
              </div>
            </div>
            {lastRoll ? (
              <Alert variant={lastRoll.win ? 'default' : 'destructive'} className={lastRoll.win ? 'border-green-500/50' : ''}>
                {lastRoll.win ? <Star className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                <AlertTitle className="font-headline text-xl">
                  {lastRoll.win ? 'You Won!' : 'You Lost'}
                </AlertTitle>
                <AlertDescription className="flex justify-between items-center">
                  <span>You rolled <span className="font-bold text-foreground">{lastRoll.roll.toFixed(2)}</span>.</span>
                  <span className={`font-bold ${lastRoll.win ? 'text-green-400' : 'text-destructive'}`}>
                    {lastRoll.profit >= 0 ? '+' : ''}${lastRoll.profit.toFixed(2)}
                  </span>
                </AlertDescription>
              </Alert>
            ) : (
                <Alert>
                <Star className="h-4 w-4" />
                <AlertTitle className="font-headline text-xl">Good Luck!</AlertTitle>
                <AlertDescription>
                  Adjust your bet and win chance, then press "Roll Dice" to start.
                </AlertDescription>
              </Alert>
            )}
            {lastGameData && (
                <div className="text-center mt-4">
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="link" size="sm">View Last Game Data</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Provably Fair Data</DialogTitle>
                            <DialogDescription>
                                Use these values on the /verify page to confirm the result was fair. The server seed is revealed after the bet.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-2 text-xs text-left overflow-auto break-words">
                            <p><strong>Unhashed Server Seed:</strong> {lastGameData.serverSeed}</p>
                            <p><strong>Server Seed Hash:</strong> {lastGameData.serverSeedHash}</p>
                            <p><strong>Client Seed:</strong> {lastGameData.clientSeed}</p>
                            <p><strong>Nonce:</strong> {lastGameData.nonce}</p>
                            <p><strong>Roll Result:</strong> {lastGameData.roll.toFixed(2)}</p>
                             <p><strong>Target (Roll Under):</strong> {lastGameData.chance.toFixed(2)}</p>
                            <p><strong>Win:</strong> {lastGameData.win ? 'Yes' : 'No'}</p>
                        </div>
                    </DialogContent>
                </Dialog>
                </div>
            )}
           </CardContent>
        </Card>
      </div>
    </>
  );
}
