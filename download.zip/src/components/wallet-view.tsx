'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ArrowLeftRight, ArrowUp, ArrowDown, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { BnbIcon, UsdtIcon } from './icons';
import { useAuth } from '@/context/auth-context';
import { TransactionHistory } from './transaction-history';

export function WalletView() {
  const { user } = useAuth();
  const qrCodeImage = PlaceHolderImages.find((img) => img.id === 'qr-code');
  // IMPORTANT: This is a placeholder address. In a real app, you would generate a unique address for each user.
  const depositAddress = user ? `0x...${user.uid.slice(-12)}` : 'YOUR_BSC_DEPOSIT_ADDRESS_HERE';
  const { toast } = useToast();

  const copyToClipboard = () => {
    navigator.clipboard.writeText(depositAddress);
    toast({
      title: 'Copied to clipboard!',
      description: 'Deposit address has been copied.',
    });
  };
  
  if (!user) {
    return (
      <Card className="bg-card/50 backdrop-blur-lg">
        <CardHeader>
          <CardTitle>Access Denied</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Please log in to view your wallet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Tabs defaultValue="deposit" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="deposit">
          <ArrowDown className="mr-2 h-4 w-4" /> Deposit
        </TabsTrigger>
        <TabsTrigger value="withdraw">
          <ArrowUp className="mr-2 h-4 w-4" /> Withdraw
        </TabsTrigger>
        <TabsTrigger value="history">
          <ArrowLeftRight className="mr-2 h-4 w-4" /> History
        </TabsTrigger>
      </TabsList>

      <TabsContent value="deposit">
        <Card className="bg-card/50 backdrop-blur-lg border-primary/20">
          <CardHeader>
            <CardTitle>Deposit Crypto</CardTitle>
            <CardDescription>
              Deposit USDT or BNB on the Binance Smart Chain (BSC) network. This is a demo; no real funds will be processed.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-grow space-y-4">
              <p className="text-muted-foreground">Send to the address below:</p>
              <div className="flex items-center gap-2 rounded-md bg-secondary p-3">
                <span className="font-mono text-sm break-all">{depositAddress}</span>
                <Button variant="ghost" size="icon" onClick={copyToClipboard}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center gap-4">
                <p>We accept:</p>
                <div className="flex items-center gap-2 text-lg font-semibold"><UsdtIcon className="w-6 h-6" /> USDT</div>
                <div className="flex items-center gap-2 text-lg font-semibold"><BnbIcon className="w-6 h-6" /> BNB</div>
              </div>
               <div className="text-xs text-amber-500/80 p-2 bg-amber-500/10 rounded-md">
                 <strong>Note:</strong> Deposits are not automated in this demo. To simulate a deposit, please contact support.
               </div>
            </div>
            {qrCodeImage && (
              <div className="p-4 bg-white rounded-lg animate-fade-in-pulse">
                <Image
                  src={qrCodeImage.imageUrl.replace('0x52f0ab1e8eb82fce46bb02e1e581f8f27a7c13ca', depositAddress)}
                  alt={qrCodeImage.description}
                  data-ai-hint={qrCodeImage.imageHint}
                  width={200}
                  height={200}
                  className="rounded-md"
                />
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="withdraw">
        <Card className="bg-card/50 backdrop-blur-lg border-primary/20">
          <CardHeader>
            <CardTitle>Withdraw Funds</CardTitle>
            <CardDescription>
              Withdraw your winnings. Please ensure the address is correct. Withdrawals are not processed in this demo.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input id="amount" placeholder="0.00" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Wallet Address (USDT/BNB on BSC)</Label>
              <Input id="address" placeholder="0x..." />
            </div>
            <Button className="w-full md:w-auto" disabled>Request Withdrawal (Demo)</Button>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="history">
        <Card className="bg-card/50 backdrop-blur-lg border-primary/20">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Your recent account activity.</CardDescription>
          </CardHeader>
          <CardContent>
            <TransactionHistory />
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
