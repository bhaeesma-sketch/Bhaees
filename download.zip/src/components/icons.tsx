import type { SVGProps } from "react";

export function UsdtIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <circle cx="12" cy="12" r="10" fill="#26A17B" />
      <path
        d="M12 6V18M9.5 6H14.5V9.5H12V14.5H9.5V6Z"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function BnbIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M12 2L6 7.00001L12 12L18 7.00001L12 2Z"
        fill="#F3BA2F"
      />
      <path
        d="M6 7.00001L12 12L6 17L-3.8147e-06 12L6 7.00001Z"
        fill="#F3BA2F"
      />
      <path
        d="M18 7.00001L24 12L18 17L12 12L18 7.00001Z"
        fill="#F3BA2F"
      />
      <path
        d="M12 12L6 17L12 22L18 17L12 12Z"
        fill="#F3BA2F"
      />
    </svg>
  );
}
