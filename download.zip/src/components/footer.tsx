export function Footer() {
  return (
    <footer className="border-t border-border/40">
      <div className="container py-4">
        <p className="text-center text-xs text-muted-foreground">
          This is a provably fair gaming platform for entertainment. Not available in restricted jurisdictions. Play at your own risk.
        </p>
      </div>
    </footer>
  );
}
