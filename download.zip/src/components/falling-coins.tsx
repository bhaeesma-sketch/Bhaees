'use client';

import React, { useState, useEffect } from 'react';
import { Coins } from 'lucide-react';

const COIN_COUNT = 30;

export function FallingCoins() {
  const [coins, setCoins] = useState<
    { id: number; style: React.CSSProperties }[]
  >([]);

  useEffect(() => {
    const screenWidth = window.innerWidth;
    const newCoins = Array.from({ length: COIN_COUNT }).map((_, i) => {
      const duration = Math.random() * 2 + 2; // 2s to 4s
      const delay = Math.random() * 1; // 0s to 1s delay
      const startX = Math.random() * screenWidth;
      const size = Math.random() * 16 + 16; // 16px to 32px

      return {
        id: i,
        style: {
          position: 'fixed',
          top: `-${size}px`,
          left: `${startX}px`,
          width: `${size}px`,
          height: `${size}px`,
          animation: `coin-fall ${duration}s ${delay}s ease-in forwards`,
          zIndex: 100,
        } as React.CSSProperties,
      };
    });
    setCoins(newCoins);
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-[200]">
      {coins.map((coin) => (
        <Coins key={coin.id} style={coin.style} className="text-primary opacity-70" />
      ))}
    </div>
  );
}
