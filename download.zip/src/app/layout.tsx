import type { Metadata } from 'next';
import { Inter, Teko } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/context/auth-context';
import { FirebaseClientProvider } from '@/firebase';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});
const teko = Teko({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-teko',
  weight: ['400', '700'],
});

export const metadata: Metadata = {
  title: 'Casino Clash',
  description: 'The ultimate crypto gaming experience.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${teko.variable}`}>
      <body className="dark font-body">
        <FirebaseClientProvider>
          <AuthProvider>
            <div className="flex min-h-screen flex-col">
              <Header />
              <main className="flex-grow container py-8">{children}</main>
              <Footer />
            </div>
            <Toaster />
          </AuthProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
