import { DiceGame } from '@/components/dice-game';

export default function DicePage() {
  return (
    <div>
      <h1 className="text-4xl font-headline mb-8 text-center">Dice</h1>
      <DiceGame />
    </div>
  );
}
