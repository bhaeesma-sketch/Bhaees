import { CoinFlipGame } from '@/components/coinflip-game';

export default function CoinFlipPage() {
  return (
    <div>
      <h1 className="text-4xl font-headline mb-8 text-center">Coin Flip</h1>
      <CoinFlipGame />
    </div>
  );
}
