import { CrashGame } from '@/components/crash-game';

export default function CrashPage() {
  return (
    <div>
      <h1 className="text-4xl font-headline mb-8 text-center">Crash</h1>
      <CrashGame />
    </div>
  );
}
