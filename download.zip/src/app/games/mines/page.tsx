import { MinesGame } from '@/components/mines-game';

export default function MinesPage() {
  return (
    <div>
      <h1 className="text-4xl font-headline mb-8 text-center">Mines</h1>
      <MinesGame />
    </div>
  );
}
