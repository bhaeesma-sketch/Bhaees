import { WalletView } from "@/components/wallet-view";

export default function WalletPage() {
    return (
        <div>
            <h1 className="text-4xl font-headline mb-8 text-center">My Wallet</h1>
            <WalletView />
        </div>
    );
}
