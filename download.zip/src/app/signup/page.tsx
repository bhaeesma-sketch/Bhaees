import { AuthForm } from "@/components/auth-form";

export default function SignupPage() {
  return (
    <div className="flex justify-center items-center">
      <AuthForm type="signup" />
    </div>
  );
}
