'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import SHA256 from 'crypto-js/sha256';
import hmacSHA256 from 'crypto-js/hmac-sha256';

// This shuffle function is a client-side port of a common provably fair algorithm.
// It's essential that this logic matches the server's for verification to work.
const shuffleArray = (array: any[], seed: string) => {
    let currentIndex = array.length;
    
    // Create a pseudo-random number generator based on the seed
    const pseudoRandom = (seedString: string) => {
        let hash = hmacSHA256(currentIndex.toString(), seedString).toString();
        // Take a piece of the hash to generate a number
        const subHash = hash.substring(hash.length - 8);
        const randomValue = parseInt(subHash, 16);
        return randomValue / 0xffffffff;
    };

    while (currentIndex !== 0) {
        const randomNum = pseudoRandom(seed + currentIndex);
        const randomIndex = Math.floor(randomNum * currentIndex);
        currentIndex--;

        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex], array[currentIndex]
        ];
    }
    return array;
};

export default function VerifyPage() {
    const [gameType, setGameType] = useState('dice');
    const [serverSeed, setServerSeed] = useState('your_strong_random_seed_here_local_and_client');
    const [clientSeed, setClientSeed] = useState('CasinoClash');
    const [nonce, setNonce] = useState('');
    const [mineCount, setMineCount] = useState('5');
    const [verificationResult, setVerificationResult] = useState<string | null>(null);

    const handleVerify = () => {
        if (!serverSeed || !clientSeed || !nonce) {
            setVerificationResult('Error: Please fill in all seed and nonce fields.');
            return;
        }

        const combined = `${serverSeed}:${clientSeed}:${nonce}`;
        const hash = SHA256(combined).toString();
        let resultText = `Combined String for Hash: ${combined}\nSHA256 Hash: ${hash}\n\n`;

        switch (gameType) {
            case 'dice':
                const roll = (parseInt(hash.substring(0, 8), 16) % 10001) / 100;
                resultText += `Dice Roll Result: ${roll.toFixed(2)}`;
                break;
            case 'crash':
                const crashHash = hash.substring(0, 13);
                // Provably fair crash point calculation
                const crashInt = parseInt(crashHash, 16);
                const e = Math.pow(2, 52);
                let crashPoint = Math.floor((e * 100) / (e - crashInt)) / 100;
                crashPoint = Math.max(1.00, crashPoint);
                resultText += `Crash Point: ${crashPoint.toFixed(2)}x`;
                break;
            case 'coinflip':
                const flipResult = parseInt(hash.substring(0, 8), 16) % 2 === 0 ? "Heads" : "Tails";
                resultText += `Coin Flip Result: ${flipResult}`;
                break;
            case 'mines':
                if (parseInt(mineCount) < 1 || parseInt(mineCount) > 24) {
                    setVerificationResult('Error: Mine count must be between 1 and 24.');
                    return;
                }
                const combinedSeedForMines = `${serverSeed}:${clientSeed}:${nonce}`;
                const grid = Array.from(Array(25).keys());
                const mines = shuffleArray(grid, combinedSeedForMines).slice(0, parseInt(mineCount));
                resultText += `Mine Locations (0-24, sorted): ${mines.sort((a,b) => a - b).join(', ')}`;
                break;
        }

        setVerificationResult(resultText);
    };

    return (
        <div>
            <h1 className="text-4xl font-headline mb-8 text-center">Verify Bet Fairness</h1>
            <Card className="max-w-2xl mx-auto">
                <CardHeader>
                    <CardTitle>Bet Verification Tool</CardTitle>
                    <CardDescription>
                        Enter the data from a past bet to cryptographically verify its outcome. The unhashed server seed is revealed to you after each bet.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="gameType">Game</Label>
                        <Select value={gameType} onValueChange={setGameType}>
                            <SelectTrigger id="gameType">
                                <SelectValue placeholder="Select a game" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="dice">Dice</SelectItem>
                                <SelectItem value="crash">Crash</SelectItem>
                                <SelectItem value="coinflip">Coin Flip</SelectItem>
                                <SelectItem value="mines">Mines</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="serverSeed">Server Seed (revealed after bet)</Label>
                        <Input id="serverSeed" value={serverSeed} onChange={(e) => setServerSeed(e.target.value)} placeholder="Server seed used for the bet" />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="clientSeed">Client Seed</Label>
                        <Input id="clientSeed" value={clientSeed} onChange={(e) => setClientSeed(e.target.value)} placeholder="Your client seed" />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="nonce">Nonce</Label>
                        <Input id="nonce" value={nonce} onChange={(e) => setNonce(e.target.value)} placeholder="Nonce from the bet (a unique number)" />
                    </div>
                    {gameType === 'mines' && (
                         <div className="space-y-2">
                            <Label htmlFor="mineCount">Number of Mines</Label>
                            <Input id="mineCount" type="number" value={mineCount} onChange={(e) => setMineCount(e.target.value)} placeholder="Number of mines in the game" />
                        </div>
                    )}
                    <Button onClick={handleVerify} className="w-full">Verify</Button>

                    {verificationResult && (
                        <div className="mt-4 p-4 bg-secondary rounded-md">
                            <h3 className="font-bold mb-2">Verification Result:</h3>
                            <pre className="text-sm whitespace-pre-wrap break-all">{verificationResult}</pre>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
