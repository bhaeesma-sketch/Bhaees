import { DiceGame } from '@/components/dice-game';
import { WelcomeBanner } from '@/components/welcome-banner';

export default function HomePage() {
  return (
    <div className="space-y-8">
      <WelcomeBanner />
      <DiceGame />
    </div>
  );
}
