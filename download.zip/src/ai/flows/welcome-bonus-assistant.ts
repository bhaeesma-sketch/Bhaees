'use server';

/**
 * @fileOverview Automatically applies a 20% welcome bonus on the user's first win and flags their account.
 *
 * - applyWelcomeBonus - A function that handles the welcome bonus application process.
 * - ApplyWelcomeBonusInput - The input type for the applyWelcomeBonus function.
 * - ApplyWelcomeBonusOutput - The return type for the applyWelcomeBonus function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ApplyWelcomeBonusInputSchema = z.object({
  userId: z.string().describe('The ID of the user receiving the bonus.'),
  winAmount: z.number().describe('The amount the user won.'),
});
export type ApplyWelcomeBonusInput = z.infer<typeof ApplyWelcomeBonusInputSchema>;

const ApplyWelcomeBonusOutputSchema = z.object({
  bonusAmount: z.number().describe('The amount of the welcome bonus applied.'),
  updatedBalance: z.number().describe('The user\'s updated balance after applying the bonus.'),
  message: z.string().describe('Confirmation message.'),
});
export type ApplyWelcomeBonusOutput = z.infer<typeof ApplyWelcomeBonusOutputSchema>;

export async function applyWelcomeBonus(input: ApplyWelcomeBonusInput): Promise<ApplyWelcomeBonusOutput> {
  return applyWelcomeBonusFlow(input);
}

const applyWelcomeBonusPrompt = ai.definePrompt({
  name: 'applyWelcomeBonusPrompt',
  input: {schema: ApplyWelcomeBonusInputSchema},
  output: {schema: ApplyWelcomeBonusOutputSchema},
  prompt: `You are a casino bonus assistant. A user with ID {{{userId}}} just won {{{winAmount}}}. Apply a 20% welcome bonus to their winnings.  Return the bonus amount, the updated balance (original win amount + bonus), and a confirmation message. Make sure bonusAmount and updatedBalance are numbers, not strings. The message should be friendly and encouraging, congratulating the user on their win and informing them about their welcome bonus.  Return a JSON object of type ApplyWelcomeBonusOutputSchema.

      For example:
      \{
        "bonusAmount": 10.00,
        "updatedBalance": 60.00,
        "message": "Congratulations! You\'ve received a $10.00 welcome bonus. Your updated balance is $60.00. This bonus is immediately withdrawable!"
      \}`,
});

const applyWelcomeBonusFlow = ai.defineFlow(
  {
    name: 'applyWelcomeBonusFlow',
    inputSchema: ApplyWelcomeBonusInputSchema,
    outputSchema: ApplyWelcomeBonusOutputSchema,
  },
  async input => {
    const {output} = await applyWelcomeBonusPrompt(input);
    return output!;
  }
);
