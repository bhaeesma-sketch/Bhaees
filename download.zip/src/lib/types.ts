export type GameType = 'dice' | 'crash' | 'mines' | 'coinflip';

export type Transaction = {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'bet' | 'win' | 'bonus';
  amount: number;
  currency: 'USDT' | 'BNB';
  status: 'completed' | 'pending' | 'failed';
  timestamp: string; // Should be ISO string
  game?: string;
  txHash?: string;
};

export type User = {
  uid: string;
  email: string;
  balance: number;
  bonusUsed: boolean;
  clientSeed: string;
  createdAt: string; // Should be ISO string
};

export type Game = {
    id?: string;
    userId: string;
    game: GameType;
    betAmount: number;
    chance: number;
    roll: number;
    win: boolean;
    payout: number;
    profit: number;
    nonce: string;
    serverSeedHash: string;
    serverSeed?: string; // Revealed after the game
    mineLocations?: number[];
    clientSeed: string;
    timestamp: string; // Should be ISO string
}
