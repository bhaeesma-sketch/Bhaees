import type { Transaction } from './types';

export const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'win',
    amount: 19.8,
    currency: 'USDT',
    status: 'completed',
    timestamp: new Date('2024-05-20T10:00:00Z'),
  },
  {
    id: '2',
    type: 'bet',
    amount: 10,
    currency: 'USDT',
    status: 'completed',
    timestamp: new Date('2024-05-20T09:59:58Z'),
  },
  {
    id: '3',
    type: 'bonus',
    amount: 100,
    currency: 'USDT',
    status: 'completed',
    timestamp: new Date('2024-05-19T15:30:00Z'),
  },
  {
    id: '4',
    type: 'deposit',
    amount: 500,
    currency: 'USDT',
    status: 'completed',
    timestamp: new Date('2024-05-19T15:25:10Z'),
    txHash: '0x123...abc',
  },
  {
    id: '5',
    type: 'withdrawal',
    amount: 250,
    currency: 'BNB',
    status: 'pending',
    timestamp: new Date('2024-05-18T12:00:00Z'),
  },
];
