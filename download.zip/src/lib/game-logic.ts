'use client';

import { doc, runTransaction, getDoc, serverTimestamp, writeBatch, collection } from 'firebase/firestore';
import type { User, Game } from '@/lib/types';
import SHA256 from 'crypto-js/sha256';
import hmacSHA256 from 'crypto-js/hmac-sha256';
import { initializeFirebase } from '@/firebase';

const { firestore } = initializeFirebase();
const db = firestore;

// In a real app, this would be securely managed and rotated on a server.
// For this client-side demo, it's a constant. It's revealed after the bet.
const SERVER_SEED = 'your_strong_random_seed_here_local_and_client';

// --- DICE GAME ---
interface DiceParams { userId: string; betAmount: number; chance: number; clientSeed: string; }
export const playDiceLogic = async ({ userId, betAmount, chance, clientSeed }: DiceParams) => {
  return runTransaction(db, async (transaction) => {
    const userRef = doc(db, 'users', userId);
    const userDoc = await transaction.get(userRef);

    if (!userDoc.exists() || userDoc.data().balance < betAmount) {
      throw new Error('Insufficient funds or user not found.');
    }
    const currentBalance = userDoc.data().balance;

    const nonce = new Date().getTime().toString();
    const hash = SHA256(`${SERVER_SEED}:${clientSeed}:${nonce}`).toString();
    const roll = (parseInt(hash.substring(0, 8), 16) % 10001) / 100;
    
    const win = roll < chance;
    const payoutMultiplier = win ? (99 / chance) : 0;
    const winAmount = betAmount * payoutMultiplier;
    const profit = winAmount - betAmount;
    const finalBalance = currentBalance + profit;

    const gameResult: Game = {
      userId,
      game: 'dice',
      betAmount,
      chance,
      roll,
      win,
      payout: payoutMultiplier,
      profit,
      nonce,
      clientSeed,
      serverSeedHash: SHA256(SERVER_SEED).toString(),
      serverSeed: SERVER_SEED, // Revealed after the bet
      timestamp: new Date().toISOString(),
    };

    transaction.update(userRef, { balance: finalBalance });
    const gameRef = doc(collection(db, `users/${userId}/games`));
    const betTransactionRef = doc(collection(db, `users/${userId}/transactions`));
    const winTransactionRef = doc(collection(db, `users/${userId}/transactions`));

    transaction.set(gameRef, { ...gameResult, timestamp: serverTimestamp() });
    transaction.set(betTransactionRef, { userId, type: 'bet', amount: betAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'dice' });
    if(win) {
      transaction.set(winTransactionRef, { userId, type: 'win', amount: winAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'dice' });
    }

    return { gameResult, finalBalance };
  });
};


// --- COINFLIP GAME ---
interface CoinflipParams { userId: string; betAmount: number; choice: 'heads' | 'tails'; clientSeed: string; }
export const playCoinFlipLogic = async ({ userId, betAmount, choice, clientSeed }: CoinflipParams) => {
    return runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', userId);
        const userDoc = await transaction.get(userRef);

        if (!userDoc.exists() || userDoc.data().balance < betAmount) {
            throw new Error('Insufficient funds.');
        }
        const currentBalance = userDoc.data().balance;

        const nonce = new Date().getTime().toString();
        const hash = SHA256(`${SERVER_SEED}:${clientSeed}:${nonce}`).toString();
        const roll = parseInt(hash.substring(0, 8), 16) % 2; // 0 for heads, 1 for tails
        const result: 'heads' | 'tails' = roll === 0 ? 'heads' : 'tails';

        const win = choice === result;
        const payoutMultiplier = win ? 1.98 : 0;
        const winAmount = betAmount * payoutMultiplier;
        const profit = winAmount - betAmount;
        const finalBalance = currentBalance + profit;

        const gameResult: Game = {
            userId,
            game: 'coinflip',
            betAmount,
            chance: 50,
            roll,
            win,
            payout: payoutMultiplier,
            profit,
            nonce,
            clientSeed,
            serverSeedHash: SHA256(SERVER_SEED).toString(),
            serverSeed: SERVER_SEED,
            timestamp: new Date().toISOString(),
        };

        transaction.update(userRef, { balance: finalBalance });
        const gameRef = doc(collection(db, `users/${userId}/games`));
        const betTransactionRef = doc(collection(db, `users/${userId}/transactions`));
        transaction.set(gameRef, { ...gameResult, timestamp: serverTimestamp() });
        transaction.set(betTransactionRef, { userId, type: 'bet', amount: betAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'coinflip' });

        if (win) {
            const winTransactionRef = doc(collection(db, `users/${userId}/transactions`));
            transaction.set(winTransactionRef, { userId, type: 'win', amount: winAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'coinflip' });
        }

        return { gameResult, finalBalance };
    });
};

// --- CRASH GAME ---
interface CrashParams { userId: string; betAmount: number; cashout: number; clientSeed: string; isAutoCashout: boolean; }
export const playCrashLogic = async ({ userId, betAmount, cashout, clientSeed, isAutoCashout }: CrashParams) => {
    return runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', userId);
        const userDoc = await transaction.get(userRef);

        if (!userDoc.exists()) throw new Error("User not found");
        const currentBalance = userDoc.data().balance;

        if (isAutoCashout && currentBalance < betAmount) {
            throw new Error("Insufficient funds");
        }

        const nonce = new Date().getTime().toString();
        const hash = SHA256(`${SERVER_SEED}:${clientSeed}:${nonce}`).toString();
        const crashHash = hash.substring(0, 13);
        const crashInt = parseInt(crashHash, 16);
        const e = Math.pow(2, 52);
        let crashPoint = Math.floor((e * 100) / (e - crashInt)) / 100;
        crashPoint = Math.max(1.00, crashPoint);

        const win = cashout < crashPoint;
        const profit = win ? betAmount * cashout - betAmount : -betAmount;
        const finalBalance = currentBalance + profit;

        const gameResult: Game = {
            userId,
            game: 'crash',
            betAmount,
            chance: cashout, // Using chance to store the cashout multiplier
            roll: crashPoint,
            win,
            payout: win ? cashout : 0,
            profit,
            nonce,
            clientSeed,
            serverSeedHash: SHA256(SERVER_SEED).toString(),
            serverSeed: SERVER_SEED,
            timestamp: new Date().toISOString(),
        };
        
        transaction.update(userRef, { balance: finalBalance });
        const gameRef = doc(collection(db, `users/${userId}/games`));
        const betTransactionRef = doc(collection(db, `users/${userId}/transactions`));
        transaction.set(gameRef, { ...gameResult, timestamp: serverTimestamp() });
        transaction.set(betTransactionRef, { userId, type: 'bet', amount: betAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'crash' });

        if (win) {
            const winTransactionRef = doc(collection(db, `users/${userId}/transactions`));
            transaction.set(winTransactionRef, { userId, type: 'win', amount: betAmount * cashout, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'crash' });
        }

        return { gameResult, finalBalance };
    });
};

// --- MINES GAME ---
const shuffleMines = (seed: string, count: number): number[] => {
    const grid = Array.from(Array(25).keys());
    for (let i = grid.length - 1; i > 0; i--) {
        const hmac = hmacSHA256(i.toString(), seed).toString();
        const index = parseInt(hmac.substring(hmac.length - 8), 16);
        const j = index % (i + 1);
        [grid[i], grid[j]] = [grid[j], grid[i]];
    }
    return grid.slice(0, count);
};

interface MinesPlayParams { userId: string; betAmount: number; mineCount?: number; clientSeed?: string; clickedIndices?: number[]; }
export const playMinesLogic = async ({ userId, betAmount, mineCount, clientSeed, clickedIndices }: MinesPlayParams) => {
    return runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', userId);
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) throw new Error("User not found");
        
        const currentBalance = userDoc.data().balance;
        const nonce = new Date().getTime().toString(); // Use a single nonce for the whole game
        let finalBalance = currentBalance;
        
        // On game start (no clicks yet)
        if (!clickedIndices || clickedIndices.length === 0) {
            if (currentBalance < betAmount) throw new Error("Insufficient funds");
            finalBalance = currentBalance - betAmount;
            transaction.update(userRef, { balance: finalBalance });
             const betTransactionRef = doc(collection(db, `users/${userId}/transactions`));
             transaction.set(betTransactionRef, { userId, type: 'bet', amount: betAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'mines' });

            return { updatedBalance: finalBalance };
        }

        // On subsequent clicks
        if (!mineCount || !clientSeed) throw new Error("Missing game parameters");
        const mineLocations = shuffleMines(`${SERVER_SEED}:${clientSeed}:${nonce}`, mineCount);
        const lastClick = clickedIndices[clickedIndices.length - 1];
        const hitMine = mineLocations.includes(lastClick);

        if (hitMine) {
            // Loss is just the bet amount, which was already deducted.
            const gameResult: Game = {
                userId, game: 'mines', betAmount, mineCount, mineLocations, win: false, profit: -betAmount,
                payout: 0, roll: -1, nonce, clientSeed, serverSeed: SERVER_SEED, serverSeedHash: SHA256(SERVER_SEED).toString(), timestamp: new Date().toISOString()
            };
            const gameRef = doc(collection(db, `users/${userId}/games`));
            transaction.set(gameRef, {...gameResult, timestamp: serverTimestamp()});
            return { gameResult, finalBalance };
        } else {
             const safeTiles = 25 - mineCount;
             let multiplier = 1;
             for (let i = 0; i < clickedIndices.length; i++) {
                 multiplier *= (1 - 0.01) * (safeTiles / (safeTiles - i));
             }
             const profit = (betAmount * multiplier) - betAmount;
             
             // This is a "peek" not a final cashout, so no balance change yet.
             return { gameResult: { win: true, profit, mineLocations:[] }, finalBalance };
        }
    });
};

interface MinesCashoutParams { userId: string; betAmount: number; mineCount: number; clientSeed: string; clickedIndices: number[]; }
export const cashoutMinesLogic = async ({ userId, betAmount, mineCount, clientSeed, clickedIndices }: MinesCashoutParams) => {
     return runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', userId);
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) throw new Error("User not found");

        const nonce = new Date().getTime().toString();
        const mineLocations = shuffleMines(`${SERVER_SEED}:${clientSeed}:${nonce}`, mineCount);
        
        const safeTiles = 25 - mineCount;
        let multiplier = 1;
        for (let i = 0; i < clickedIndices.length; i++) {
            multiplier *= (1 - 0.01) * (safeTiles / (safeTiles - i));
        }

        const winAmount = betAmount * multiplier;
        const profit = winAmount - betAmount;
        const finalBalance = userDoc.data().balance + winAmount; // Add full win amount, as bet was pre-deducted.

        const gameResult: Game = {
            userId, game: 'mines', betAmount, mineCount, mineLocations, win: true, profit,
            payout: multiplier, roll: clickedIndices.length, nonce, clientSeed, 
            serverSeed: SERVER_SEED, serverSeedHash: SHA256(SERVER_SEED).toString(), timestamp: new Date().toISOString()
        };

        transaction.update(userRef, { balance: finalBalance });
        const gameRef = doc(collection(db, `users/${userId}/games`));
        const winTransactionRef = doc(collection(db, `users/${userId}/transactions`));
        transaction.set(gameRef, {...gameResult, timestamp: serverTimestamp()});
        transaction.set(winTransactionRef, { userId, type: 'win', amount: winAmount, currency: 'USDT', status: 'completed', timestamp: serverTimestamp(), game: 'mines' });

        return { gameResult, finalBalance };
    });
}
