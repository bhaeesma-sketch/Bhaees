// This file is automatically populated by Firebase App Hosting.
export const firebaseConfig = {
  "projectId": "studio-3325568043-a8be8",
  "appId": "1:930193851569:web:11bc1363b7c8ba27a88e90",
  "apiKey": "AIzaSyAbnv5GPKZF0kZ3kBlLR1EVTz_MASb5As4",
  "authDomain": "studio-3325568043-a8be8.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "930193851569"
};
