'use client';

import type { User as AppUser } from '@/lib/types';
import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
  useCallback,
} from 'react';
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { initializeFirebase } from '@/firebase';

const { auth, firestore } = initializeFirebase();

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (email: string, pass: string) => Promise<void>;
  logout: () => void;
  updateBalance: (newBalance: number) => void;
  setBonusUsed: () => void;
  clientSeed: string;
  setClientSeed: (seed: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [clientSeed, setClientSeedState] = useState('CasinoClash');

  const fetchAppUser = useCallback(async (firebaseUser: FirebaseUser): Promise<AppUser | null> => {
    const userDocRef = doc(firestore, 'users', firebaseUser.uid);
    const userDoc = await getDoc(userDocRef);
    if (userDoc.exists()) {
      const userData = userDoc.data() as AppUser;
      // Ensure local state is in sync with Firestore
      setClientSeedState(userData.clientSeed || 'CasinoClash');
      return { ...userData, uid: firebaseUser.uid };
    }
    return null;
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true);
      if (firebaseUser) {
        const appUser = await fetchAppUser(firebaseUser);
        if (appUser) {
          setUser(appUser);
        } else {
          // If user exists in Auth but not in Firestore, create their record
          const newUser: Omit<AppUser, 'uid' | 'createdAt'> = {
            email: firebaseUser.email!,
            balance: 1000.00, // Starting balance
            bonusUsed: false,
            clientSeed: 'CasinoClash',
          };
          const userDocRef = doc(firestore, 'users', firebaseUser.uid);
          await setDoc(userDocRef, { ...newUser, createdAt: serverTimestamp() });
          setUser({ ...newUser, uid: firebaseUser.uid, createdAt: new Date().toISOString() });
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [fetchAppUser]);

  const login = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const signup = async (email: string, pass: string) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
    const firebaseUser = userCredential.user;
    const newUser: Omit<AppUser, 'uid' | 'createdAt'> = {
      email: firebaseUser.email!,
      balance: 1000.00,
      bonusUsed: false,
      clientSeed: 'CasinoClash',
    };
    const userDocRef = doc(firestore, 'users', firebaseUser.uid);
    await setDoc(userDocRef, { ...newUser, createdAt: serverTimestamp() });
    setUser({ ...newUser, uid: firebaseUser.uid, createdAt: new Date().toISOString() });
  };

  const logout = async () => {
    await signOut(auth);
  };

  const updateBalance = useCallback((newBalance: number) => {
    setUser(currentUser => currentUser ? { ...currentUser, balance: newBalance } : null);
  }, []);

  const setBonusUsed = useCallback(() => {
    if (!user) return;
    setUser(currentUser => currentUser ? { ...currentUser, bonusUsed: true } : null);
    // The database update is now handled by the game logic flow.
  }, [user]);

  const setClientSeed = useCallback(async (seed: string) => {
    if (!user) return;
    setClientSeedState(seed);
    setUser(currentUser => currentUser ? { ...currentUser, clientSeed: seed } : null);
    const userDocRef = doc(firestore, 'users', user.uid);
    try {
      await updateDoc(userDocRef, { clientSeed: seed });
    } catch (error) {
      console.error("Failed to update client seed in Firestore:", error);
    }
  }, [user]);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        signup,
        logout,
        updateBalance,
        setBonusUsed,
        clientSeed,
        setClientSeed,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
